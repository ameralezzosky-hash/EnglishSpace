import React, { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Rocket, MessageSquare, GraduationCap, Star, Globe2, CheckCircle2, PlayCircle, Brain, Headphones, Mail, Phone, MapPin, ArrowRight, Sparkles, Heart } from 'lucide-react'

const Feature = ({icon, title, desc}) => (
  <div className="rounded-2xl p-5 bg-white shadow-sm border h-full">
    <div className="flex items-center gap-2 text-sky-700 font-semibold mb-2">{icon}{title}</div>
    <p className="text-sm text-neutral-600">{desc}</p>
  </div>
)

const Plan = ({name, price, tagline, features, highlighted}) => (
  <div className={`rounded-2xl p-6 bg-white border ${highlighted ? 'border-sky-300 shadow-lg' : 'shadow-sm'}`}>
    <div className="flex items-center justify-between font-semibold mb-1">
      <span>{name}</span>
      <span className="text-sky-700 text-lg">{price}</span>
    </div>
    <div className="text-sm text-neutral-600 mb-4">{tagline}</div>
    <ul className="space-y-2 text-sm mb-4">
      {features.map((f,i)=>(<li key={i} className="flex items-start gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5"/>{f}</li>))}
    </ul>
    <button className="w-full rounded-2xl py-2.5 bg-sky-600 text-white hover:bg-sky-700 transition">Select</button>
  </div>
)

function useSampleFlashcards() {
  return useMemo(() => [
    { front: 'collaboration', back: 'working together to achieve a goal' },
    { front: 'reliable', back: 'can be trusted; dependable' },
    { front: 'summarize', back: 'to state the main points briefly' },
    { front: 'nevertheless', back: 'in spite of that; however' },
  ], [])
}

function Flashcards() {
  const cards = useSampleFlashcards()
  const [i, setI] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const next = () => { setFlipped(false); setI((i+1)%cards.length) }
  return (
    <div className="max-w-xl mx-auto">
      <div className="rounded-2xl overflow-hidden bg-white shadow-lg border">
        <div className="px-6 py-3 bg-gradient-to-r from-sky-500 to-cyan-500 text-white font-semibold flex items-center gap-2">
          <Globe2 className="w-5 h-5"/> Vocabulary Flashcards
        </div>
        <div className="p-6">
          <motion.div className="h-40 grid place-items-center rounded-xl border bg-white/70 backdrop-blur cursor-pointer relative"
            onClick={()=>setFlipped(!flipped)}
            initial={false} animate={{ rotateY: flipped ? 180 : 0 }} transition={{ duration: .5 }}
            style={{ transformStyle: 'preserve-3d' }}>
            <div className="text-2xl font-semibold" style={{ backfaceVisibility:'hidden' }}>{cards[i].front}</div>
            <div className="absolute text-lg text-center px-6" style={{ transform:'rotateY(180deg)', backfaceVisibility:'hidden' }}>{cards[i].back}</div>
          </motion.div>
          <div className="mt-4 flex items-center justify-between">
            <div className="text-sm text-neutral-600">Card {i+1} / {cards.length}</div>
            <button onClick={next} className="rounded-2xl px-4 py-2 bg-neutral-100 hover:bg-neutral-200 border">Next</button>
          </div>
        </div>
      </div>
    </div>
  )
}

function QuickQuiz() {
  const q = { prompt: 'Choose the best sentence:', options: ['She don\'t likes coffee.','She doesn\'t like coffee.','She isn\'t like coffee.'], answer: 1 }
  const [picked, setPicked] = useState(null)
  const correct = picked === q.answer
  return (
    <div className="rounded-2xl p-6 bg-white border shadow-sm">
      <div className="font-semibold flex items-center gap-2 mb-3"><PlayCircle className="w-5 h-5"/>60‑second Quiz</div>
      <p className="font-medium mb-3">{q.prompt}</p>
      <div className="grid gap-2">
        {q.options.map((o, idx)=>(
          <button key={idx} onClick={()=>setPicked(idx)}
            className={`text-left h-auto py-3 px-4 rounded-xl border ${picked===idx ? (correct?'bg-emerald-50 border-emerald-300':'bg-rose-50 border-rose-300') : 'bg-neutral-50 hover:bg-neutral-100'}`}>
            {o}
          </button>
        ))}
      </div>
      {picked!==null && <div className={`text-sm mt-2 ${correct?'text-emerald-700':'text-rose-700'}`}>{correct?'Great job! That\'s correct.':'Not quite—review present simple with do/does.'}</div>}
    </div>
  )
}

const features = [
  { icon: <MessageSquare className="w-5 h-5"/>, title: 'Speak with Confidence', desc: 'Live conversation rooms moderated by certified teachers.' },
  { icon: <BookOpen className="w-5 h-5"/>, title: 'Grammar that Sticks', desc: 'Micro-lessons with instant practice & feedback.' },
  { icon: <Headphones className="w-5 h-5"/>, title: 'Native Listening', desc: 'Daily audio stories at beginner, intermediate & advanced levels.' },
  { icon: <Brain className="w-5 h-5"/>, title: 'Smart Review', desc: 'Spaced-repetition flashcards for long‑term memory.' },
]

const plans = [
  { name:'Starter', price:'Free', tagline:'Try it out', features:['10 lessons','Basic quizzes','Community access'], highlighted:false },
  { name:'Pro', price:'$19/mo', tagline:'Best for learners', features:['All lessons','Live rooms (weekly)','Progress tracking','Download PDFs'], highlighted:true },
  { name:'Teams', price:'$59/mo', tagline:'Schools & groups', features:['Up to 10 seats','Teacher dashboard','Assignments & reports'], highlighted:false },
]

const levels = [
  { title:'Beginner (A1–A2)', bullets:['Introduce yourself','Daily routines','Basic tenses'], color:'from-teal-500 to-emerald-500' },
  { title:'Intermediate (B1–B2)', bullets:['Clear opinions','Work & study','Complex sentences'], color:'from-indigo-500 to-sky-500' },
  { title:'Advanced (C1–C2)', bullets:['Academic English','Business writing','Presentation skills'], color:'from-fuchsia-500 to-rose-500' },
]

export default function App() {
  return (
    <div>
      {/* Nav */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 font-extrabold text-lg">
            <Rocket className="w-5 h-5 text-sky-600"/>
            <span>English <span className="text-sky-600">Space</span></span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#levels" className="hover:text-sky-600">Levels</a>
            <a href="#features" className="hover:text-sky-600">Features</a>
            <a href="#sample" className="hover:text-sky-600">Sample</a>
            <a href="#pricing" className="hover:text-sky-600">Pricing</a>
            <a href="#contact" className="hover:text-sky-600">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <button className="hidden md:inline-flex rounded-2xl px-4 py-2 border">Sign in</button>
            <button className="rounded-2xl px-4 py-2 bg-sky-600 text-white hover:bg-sky-700">Start Free</button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-sky-50 via-white to-cyan-50"></div>
        <div className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.6}} className="text-4xl md:text-5xl font-extrabold tracking-tight">
              Learn English with confidence in <span className="text-sky-600">English Space</span>
            </motion.h1>
            <p className="mt-4 text-lg text-neutral-600">
              Bite‑sized lessons, live speaking rooms, and smart review—everything you need to become fluent.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button className="rounded-2xl px-4 py-2 bg-sky-600 text-white hover:bg-sky-700 flex items-center gap-2"><Sparkles className="w-4 h-4"/>Start free lesson</button>
              <button className="rounded-2xl px-4 py-2 border flex items-center gap-2"><PlayCircle className="w-4 h-4"/>Watch how it works</button>
            </div>
            <div className="mt-6 flex items-center gap-4 text-sm text-neutral-600">
              <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600"/> CEFR‑aligned</div>
              <div className="flex items-center gap-2"><GraduationCap className="w-4 h-4 text-emerald-600"/> Certified teachers</div>
              <div className="flex items-center gap-2"><Heart className="w-4 h-4 text-rose-500"/> 1M+ practice sessions</div>
            </div>
          </div>
          <motion.div initial={{opacity:0,scale:.95}} animate={{opacity:1,scale:1}} transition={{duration:.6, delay:.1}} className="md:justify-self-end">
            <div className="bg-white rounded-3xl p-6 shadow-xl border w-full max-w-md">
              <div className="text-sm font-semibold text-sky-700 mb-2">Mini Lesson • Present Simple</div>
              <div className="rounded-xl bg-sky-50 p-4">
                <div className="font-semibold">Rule</div>
                <p className="text-sm text-slate-700">Use <span className="font-semibold">do/does</span> + base verb for negatives & questions in the present simple.</p>
                <div className="mt-3 text-sm"><span className="font-semibold">Example:</span> She <span className="underline decoration-rose-400 decoration-2">doesn't like</span> coffee.</div>
              </div>
              <div className="mt-4"><QuickQuiz/></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Levels */}
      <section id="levels" className="py-14">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Courses for every level</h2>
          <p className="text-neutral-600 mt-2">From your first words to professional fluency.</p>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {levels.map((lvl, idx)=>(
              <div key={idx} className="rounded-2xl shadow-md bg-white border overflow-hidden">
                <div className={`px-6 py-4 text-white bg-gradient-to-r ${lvl.color}`}>
                  <div className="text-xl font-semibold">{lvl.title}</div>
                </div>
                <div className="p-6">
                  <ul className="space-y-2 text-sm">
                    {lvl.bullets.map((b,i)=>(<li key={i} className="flex items-start gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5"/>{b}</li>))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-14 bg-white border-y">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Why learners love English Space</h2>
          <div className="mt-8 grid md:grid-cols-4 gap-6">
            {features.map((f, idx)=>(<Feature key={idx} icon={f.icon} title={f.title} desc={f.desc}/>))}
          </div>
        </div>
      </section>

      {/* Sample + Flashcards */}
      <section id="sample" className="py-14">
        <div className="max-w-6xl mx-auto px-4 grid lg:grid-cols-2 gap-8 items-start">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Try a quick practice</h2>
            <p className="text-neutral-600 mt-2">Flip the card to see the meaning, then move to the next.</p>
            <div className="mt-6"><Flashcards/></div>
          </div>
          <div>
            <h3 className="text-xl font-semibold flex items-center gap-2"><GraduationCap className="w-5 h-5"/> Lesson outcomes</h3>
            <ul className="mt-3 space-y-2 text-sm">
              <li className="flex gap-2 items-start"><CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5"/> Use the present simple for habits & facts.</li>
              <li className="flex gap-2 items-start"><CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5"/> Make grammatically correct negatives & questions.</li>
              <li className="flex gap-2 items-start"><CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5"/> Build vocabulary with context-based examples.</li>
            </ul>
            <div className="mt-6 grid md:grid-cols-2 gap-4">
              <div className="rounded-2xl p-6 bg-white border shadow-sm h-full">
                <div className="flex items-center gap-2 text-amber-500 mb-2">
                  {[...Array(5)].map((_,i)=>(<Star key={i} className="w-4 h-4 fill-current" />))}
                </div>
                <p className="text-neutral-600">“The live rooms gave me real speaking confidence.”</p>
                <div className="mt-4 font-semibold">Amira</div>
                <div className="text-sm text-neutral-600">Nurse, UAE</div>
              </div>
              <div className="rounded-2xl p-6 bg-white border shadow-sm h-full">
                <div className="flex items-center gap-2 text-amber-500 mb-2">
                  {[...Array(5)].map((_,i)=>(<Star key={i} className="w-4 h-4 fill-current" />))}
                </div>
                <p className="text-neutral-600">“Short lessons fit my schedule — and I finally remember!”</p>
                <div className="mt-4 font-semibold">Marco</div>
                <div className="text-sm text-neutral-600">Student, KSA</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-14 bg-white border-t">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Simple pricing</h2>
          <p className="text-neutral-600 mt-2">Pick a plan and launch your journey.</p>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {plans.map((p, idx)=>(<Plan key={idx} name={p.name} price={p.price} tagline={p.tagline} features={p.features} highlighted={idx===1}/>))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="bg-gradient-to-r from-sky-600 to-cyan-600 rounded-3xl p-8 md:p-12 text-white grid md:grid-cols-2 gap-6 items-center shadow-xl">
            <div>
              <h3 className="text-3xl font-extrabold">Join English Space today</h3>
              <p className="mt-2 text-white/90">Start free, learn daily, and speak confidently in weeks.</p>
            </div>
            <div className="md:justify-self-end flex gap-3">
              <a href="#pricing" className="rounded-2xl px-4 py-2 bg-white text-sky-700 hover:bg-white/90">Create free account</a>
              <a href="#contact" className="rounded-2xl px-4 py-2 border border-white/60">Book a demo <ArrowRight className="w-4 h-4 inline ml-2"/></a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-14 bg-white border-t">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-3 gap-6 items-start">
          <div className="md:col-span-2">
            <h2 className="text-3xl font-bold tracking-tight">Get in touch</h2>
            <p className="text-neutral-600 mt-2">Questions about courses or group plans? We’d love to help.</p>
            <form onSubmit={(e)=>e.preventDefault()} className="mt-6 grid gap-4">
              <div className="grid md:grid-cols-2 gap-4">
                <input className="border rounded-xl p-3" placeholder="Name"/>
                <input className="border rounded-xl p-3" placeholder="Email" type="email"/>
              </div>
              <textarea className="border rounded-xl p-3 min-h-[120px]" placeholder="Your message"></textarea>
              <button className="rounded-2xl px-4 py-2 bg-sky-600 text-white hover:bg-sky-700 w-fit">Send message</button>
            </form>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-2"><Mail className="w-4 h-4"/> hello@englishspace.app</div>
            <div className="flex items-center gap-2"><Phone className="w-4 h-4"/> +971 55 000 0000</div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4"/> Dubai • Riyadh • Cairo</div>
          </div>
        </div>
      </section>

      <footer className="py-10">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-neutral-600">
          <div className="flex items-center gap-2 font-semibold"><Rocket className="w-4 h-4 text-sky-600"/> English Space</div>
          <div>© {new Date().getFullYear()} English Space. All rights reserved.</div>
        </div>
      </footer>
    </div>
  )
}
